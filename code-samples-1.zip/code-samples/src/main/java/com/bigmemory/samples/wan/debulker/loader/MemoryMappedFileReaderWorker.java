package com.bigmemory.samples.wan.debulker.loader;

import java.nio.MappedByteBuffer;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.stream.Stream;

import com.bigmemory.samples.wan.debulker.service.DebulkingStrategy;
import com.bigmemory.samples.wan.debulker.transformer.CSVTransformer;
import com.bigmemory.samples.wan.events.EventHandler;
import com.bigmemory.samples.wan.events.registration.RegistrationEvent;

public class MemoryMappedFileReaderWorker<T> implements Callable<String[]> {

	private MappedByteBuffer buffer;
	
	private final int batchSize;
	private RegistrationEvent[] events;
	private String[] response = new String[0];//20,000,000	100,000,000
	private String[] lines;
	private EventHandler<RegistrationEvent>[] eventHandlers;
	protected final BlockingQueue<String> queue;
	
	public MemoryMappedFileReaderWorker(MappedByteBuffer buffer,
										DebulkingStrategy debulkingStrategy,
										BlockingQueue<String> queue) {
		this.buffer = buffer;
		
		this.batchSize = debulkingStrategy.getBatchSize();
		this.eventHandlers = debulkingStrategy.getEventHandlers();
		if(batchSize>0) {
			if(eventHandlers != null && eventHandlers.length>0) {
				this.events = new RegistrationEvent[batchSize];
			}
			this.lines = new String[batchSize];
		}
		this.queue = queue;
		
		Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
	}
//	
//	public T read() {
//		return (T)call();
//	}
	
	final long start = System.currentTimeMillis();
	
	@Override
	public String[] call() {
		
		System.out.println("Chunk size " + Thread.currentThread().getId() + "\t" + buffer.limit() + " bytes");
		
		int idx = 0;										//Metrics
//		long elapsed; int tps, it = 0, j = 0;				//Metrics
		Instant start = Instant.now();						//Metrics
		for(int i=0; i<buffer.limit(); i++) {
			
			StringBuilder line = new StringBuilder();
			char character;
			while((character = (char) buffer.get())!= '\r') {
				i++;
				line.append(character);
			}
			lines[idx] = line.toString();
			
			/** Batching prior to caching */
			if(batchSize>0) {
				/** Batch events */
				if(events != null)
					events[idx] = new RegistrationEvent(CSVTransformer.transformCSVLine(line.toString()));
				if(((idx+1) % batchSize) == 0) { //TODO:
					for(EventHandler<RegistrationEvent> eventHandler : eventHandlers)
						eventHandler.handleAll(events);
					if(events != null)
						events = new RegistrationEvent[batchSize];
					if(queue != null)
						queue.addAll(Arrays.asList(lines));

					//System.arraycopy(lines, 0, response, it*batchSize, idx+1);//Collect response, once per batch operation
					response = Stream.concat(Stream.of(response), Stream.of(lines)).toArray(String[]::new);
					
					lines = new String[batchSize];
					idx = 0;
					//++it;
				} else {
					++idx;
				}
			} else {
				response = Stream.concat(Arrays.stream(response), Arrays.stream(new String[]{line.toString()})).toArray(String[]::new);//response[j] = line.toString();
				for(EventHandler<RegistrationEvent> eventHandler : eventHandlers)
					eventHandler.handle(new RegistrationEvent(CSVTransformer.transformCSVLine(line.toString())));
				try {
					if(queue != null)
						queue.put(line.toString());//.offer(line.toString(), 2, TimeUnit.MILLISECONDS);//.put(line.toString());
				} catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
			
//			elapsed = Duration.between(start, Instant.now()).toMillis();
//			tps = ((int)elapsed/1000 > 0) ? ((int)j/((int)elapsed/1000)) : 0;
//			System.out.print(tps + "\r");
//			System.out.print(Thread.currentThread().getId() + "\t" + j + "\t\t" + MetricsUtil.formatMillis(elapsed) + "\t\t" + tps + "\r");

			line.setLength(0);
//			++j;								//Metrics
		}
		//response = Arrays.copyOf(response, j);// System.arraycopy(response, 0, response, 0, j);//Compress response
		
	    System.out.println(Thread.currentThread().getId() + "\tETL-ed\t\t" + response.length + " registrations, in " + Duration.between(start, Instant.now()).toMillis() + " milliseconds");

//	    buffer = null;
//	    System.gc();
	    
	    return response;
	}
	
	public void terminate() {
		System.out.println(Thread.currentThread().getId() + " terminated");
	}
	
}
package com.bigmemory.samples.wan.debulker.async;

import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.bigmemory.samples.wan.events.EventHandler;
import com.bigmemory.samples.wan.events.registration.RegistrationEvent;

public class RabbitMQClient implements MQClient<RegistrationEvent>, EventHandler<RegistrationEvent> {

	@Autowired
	private String hostname = "localhost";
	@Autowired
	private String queuename = "lookup_audit";

	private final ConnectionFactory factory = new ConnectionFactory();

	private Connection connection;
	private Channel channel;
	
	private boolean isConnected = false;

	public RabbitMQClient() {
		;
	}

	public void init() {

		factory.setHost(hostname);
		try {
			connection = factory.newConnection();
			channel = connection.createChannel();
			
			isConnected = true;
		} catch (Exception e) {
			;
		}
//		channel.close();
//	    connection.close();
	}

	@Override
	public void handle(RegistrationEvent message) {
		if(!isConnected)
			return;

		send(message);
	}

	@Override
	public Integer handleAll(RegistrationEvent[] messages) {
		if(!isConnected)
			return 0;

		for(RegistrationEvent message : messages)
			handle(message);
		return messages.length;
	}

	@Override
	public void send(RegistrationEvent event) {
		
		String message = event.getEventBody().toString();
		try {
			channel.queueDeclare(queuename, false, false, false, null);
			channel.basicPublish("", queuename, null, message.getBytes());
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getQueuename() {
		return queuename;
	}

	public void setQueuename(String queuename) {
		this.queuename = queuename;
	}

	@Override
	public boolean isConnected() {

		return isConnected;
	}

}
package com.bigmemory.samples.wan.debulker.util;

import java.lang.reflect.Array;
import java.util.Arrays;

public abstract class ArrayUtils {
	
	/**
	 * Concatenates the two arrays
	 * @param a
	 * @param b
	 * @return
	 */
	public static String[] combine(String[] a, String[] b) {
		
		String[] result = new String[a.length + b.length];
		System.arraycopy(a, 0, result, 0, a.length);
		System.arraycopy(b, 0, result, a.length, b.length);
		return result;
	}

	public static <T> T[] concatenateArrays(T[] a, T[] b) {
		int aLen = a.length;
		int bLen = b.length;

		@SuppressWarnings("unchecked")
		T[] c = (T[]) Array.newInstance(a.getClass().getComponentType(), aLen+bLen);
		System.arraycopy(a, 0, c, 0, aLen);
		System.arraycopy(b, 0, c, aLen, bLen);

		return c;
	}

	/**
	 * 
	 * @param first
	 * @param rest
	 * @return
	 */
	public static <T> T[] concatAll(T[] first, @SuppressWarnings("unchecked") T[]... rest) {
		
		int totalLength = first.length;
		for(T[] array : rest)
			totalLength += array.length;

		T[] result = Arrays.copyOf(first, totalLength);
		int offset = first.length;
		for(T[] array : rest) {
			System.arraycopy(array, 0, result, offset, array.length);
			offset += array.length;
		}
		return result;
	}
	
	/**
	 * Dynamically resizes 
	 * @param array
	 * @param newSize
	 * @return
	 */
	public final static Object resizeArray(Object array, int newSize) {
		
		int oldSize = Array.getLength(array);
		Class<?> elementType = array.getClass().getComponentType();
		Object newArray = Array.newInstance(elementType, newSize);
		int preserveLength = Math.min(oldSize, newSize);
		if(preserveLength>0)
			System.arraycopy(array, 0, newArray, 0, preserveLength);
		return newArray;
	}

}
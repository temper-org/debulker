package com.bigmemory.samples.wan.debulker.profiler;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class ServiceProfiler {
	
	final static Logger LOG = LoggerFactory.getLogger(ServiceProfiler.class);

	//Double period for recursively scanning the packages
	@Pointcut("execution(* com.bigmemory.samples.wan..*.*(..))"
			+ "&& !execution(* com.bigmemory.samples.wan.debulker.FilebasedDebulkingService.DefaultDebulkingStrategy*.*(..))"
			+ "&& !execution(* com.bigmemory.samples.wan.debulker.loader.MemoryMappedFileReader.getDebulkingStrategy(..))")
	public void businessMethods() {
		;
	}

	@Around("businessMethods()")
	public Object profile(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {

		Runtime runtime = Runtime.getRuntime();
	    runtime.gc();														//GC
	    long memoryBefore = runtime.totalMemory() - runtime.freeMemory();	//RAM utilisation
	    
		long start = System.currentTimeMillis();							//Latency
		Object output = proceedingJoinPoint.proceed();
		long memoryAfter = runtime.totalMemory() - runtime.freeMemory();
		
		final long elapsed = System.currentTimeMillis() - start;
		
		float tps = 0;
		if(output instanceof Integer && elapsed/1000>0)
			tps = ((Integer)output)/(elapsed/1000);
		if(output instanceof String[] && elapsed/1000>0)
			tps = ((String[])output).length/(elapsed/1000);
//		LOG.info("\t" + elapsed + "\tms" + "\t" + bytesToMegabytes(memoryAfter - memoryBefore) + " \tMB\t" + ((tps<1) ? "N/A" : tps) + "\tTPS\t" + proceedingJoinPoint.toShortString());
		
		//LOG.info("\t" + elapsed + "\tms" + "\t" + bytesToMegabytes(memoryAfter - memoryBefore) + " \tMB\t" + proceedingJoinPoint.toShortString());

		LOG.info("Profiler: " + "Elapsed: " + elapsed + " ms. RAM: " + bytesToMegabytes(memoryAfter - memoryBefore) + " MB. Throughput: " + ((tps<1) ? "N/A" : tps) + " TPS. Location: " + proceedingJoinPoint.toShortString());
		return output;
	}

	private static final long MEGABYTE = 1024L*1024L;

	public static long bytesToMegabytes(long bytes) {
		return bytes/MEGABYTE;
	}
}
package com.bigmemory.samples.wan.events;

public interface Event<T> {
	
	public Long getEventID();
	public T getEventBody();

}

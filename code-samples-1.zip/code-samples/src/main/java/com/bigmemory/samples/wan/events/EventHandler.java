package com.bigmemory.samples.wan.events;

public interface EventHandler<T> {

	public void handle(T t);
	public Integer handleAll(T[] t);
}

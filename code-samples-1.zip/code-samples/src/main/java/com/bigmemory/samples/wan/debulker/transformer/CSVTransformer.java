package com.bigmemory.samples.wan.debulker.transformer;

import com.bigmemory.samples.wan.events.registration.RegistrationVO;

/**
 * 
 * @author dennis.temper
 *
 */
public class CSVTransformer implements Transformer<RegistrationVO, String[]> {
	
	private final static CSVTransformer TRANSFORMER = new CSVTransformer();

	/**
	 * 
	 */
	public RegistrationVO transform(String[] data) {

		try {
			return new RegistrationVO(Long.parseLong(data[0]), data[1], data[2],
													Long.parseLong(data[3]), data[4],
													Boolean.parseBoolean(data[5]), data[6], data[7], data[8],
													Boolean.parseBoolean(data[9]), data[11], data[12], data[13]);
		} catch(Exception e) {
			//TODO: return validation error
			return null;
		}
	}

	public static RegistrationVO transformCSVLine(String line) {

		return TRANSFORMER.transform(line.split(","));
	}
}
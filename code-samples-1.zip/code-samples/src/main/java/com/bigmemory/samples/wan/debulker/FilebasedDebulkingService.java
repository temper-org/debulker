package com.bigmemory.samples.wan.debulker;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bigmemory.samples.wan.debulker.loader.FileReader;
import com.bigmemory.samples.wan.debulker.reporting.FileWriter;
import com.bigmemory.samples.wan.debulker.reporting.MemoryMappedFileWriterWorker;
import com.bigmemory.samples.wan.debulker.service.DebulkingStrategy;
import com.bigmemory.samples.wan.debulker.service.FileType;
import com.bigmemory.samples.wan.debulker.util.FileUtils;
import com.bigmemory.samples.wan.events.EventHandler;
import com.bigmemory.samples.wan.events.registration.RegistrationEvent;

public class FilebasedDebulkingService implements DebulkingService {

	@Autowired
	private FileReader fileReader;
	public void setFileReader(FileReader fileReader) {
		this.fileReader = fileReader;
	}
	
	@Autowired
	private FileWriter fileWriter;
	public void setFileWriter(FileWriter fileWriter) {
		this.fileWriter = fileWriter;
	}
	
	@Override
	public void updateDebulkingStrategy(EventHandler<RegistrationEvent> eventHandler) {
		this.fileReader.getDebulkingStrategy().addEventHandler(eventHandler);
	}
	
	/**
	 * Single threaded serial processing
	 */
	@Override
	public final Integer debulk() {
		
		File file = new File(fileReader.getDebulkingStrategy().getSource());
		RandomAccessFile randomAccessFile = null;
		FileChannel fileChannel = null;
		try {
			randomAccessFile = new RandomAccessFile(file, "r");
			fileChannel = randomAccessFile.getChannel();
			
			String[] results = null;
			for(MappedByteBuffer chunk : FileUtils.slice(fileChannel))
				if(results == null)
					results = fileReader.read(chunk);
				else
					results = Stream.concat(Arrays.stream(results),
							Arrays.stream(fileReader.read(chunk)))
								.toArray(String[]::new);
			
			if(fileReader.getDebulkingStrategy().generateReport())
				fileWriter.write(results);
			return results.length;
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fileChannel.close();
				randomAccessFile.close();
			} catch (IOException e) {
				;
			}
		}
		return 0;
	}
	
	public final void debulkSerial() {
		
		File file = new File(fileReader.getDebulkingStrategy().getSource());
		RandomAccessFile randomAccessFile = null;
		try {
			randomAccessFile = new RandomAccessFile(file, "r");
			FileChannel fileChannel = randomAccessFile.getChannel();
			
			String[] results = null;
			/**
			 * Multithreaded parallel processing
			 */
			BlockingQueue<String> queue = null;
			/** Compose executor framework */
			ExecutorService executor = Executors.newFixedThreadPool(2);
			Set<Future<String[]>> futures = new HashSet<Future<String[]>>();

			/** Create producers -  */
			Callable<String[]>[] processors = FileUtils.getProcessors(queue, fileChannel, fileReader.getDebulkingStrategy());
			for(Callable<String[]> reader : processors) {
				Future<String[]> future = executor.submit(reader);
				futures.add(future);
			}

			//fileChannel.close();randomAccessFile.close();//System.gc();
			
			/** Get results */
			for(Future<String[]> future : futures) {
				if(results == null)
					results = future.get();
				else
					results = Stream.concat(Arrays.stream(results), Arrays.stream(future.get())).toArray(String[]::new);
			}
			new MemoryMappedFileWriterWorker(queue, fileReader.getDebulkingStrategy().getFilename()).writeReportLines(results);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			;
		}
	}

	int[] a= new int[]{};

	public final static void main(String[] args) throws Exception {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		try {
			DebulkingService service = (DebulkingService) context.getBean("serviceClass");
			service.debulk();
		} finally {
			((ClassPathXmlApplicationContext)context).close();
		}
		
		/** BigMemory Max Cache simulator section */
//		EventHandler<RegistrationEvent>[] eventHandlers = new EventHandler[]{new EventHandler<RegistrationEvent>() {
//			@Override
//			public void handle(RegistrationEvent t) {
//				System.out.println(t.getEventBody());
//			}
//			@Override
//			public void handleAll(RegistrationEvent[] elements) {
//				System.out.println(elements[0].getEventBody());
//				//Collection<Element> es = new ArrayList<Element>(Arrays.asList(elements));
//				//System.out.println(es.size());
//			}
//		}};
		
//		new FilebasedDebulkingService().debulk(getDebulkingStrategy());
		System.exit(0);
	}

	static class DefaultDebulkingStrategy implements DebulkingStrategy {

		@Autowired private String source;			//	= "C:/dennis/Vocalink/10m.csv";
		@Autowired private String destination;		//	= "C:/dennis/Vocalink/10mi.csv";
		@Autowired private boolean generateReport;	//	= true;
		@Autowired private int queueSize;			//	= 10000000;	10 mln
		@Autowired private int batchSize;			//	=  1000000;	1 mln;
		
		@SuppressWarnings("unchecked")
		private EventHandler<RegistrationEvent>[] eventHandlers = new EventHandler[0];

		public DefaultDebulkingStrategy() {
			;
		}
		public DefaultDebulkingStrategy(EventHandler<RegistrationEvent>[] eventHandlers) {
			if(eventHandlers != null)
				this.eventHandlers = eventHandlers;
		}

		@Override
		public void addEventHandler(EventHandler<RegistrationEvent> eventHandler) {
			eventHandlers = Arrays.copyOf(eventHandlers, eventHandlers.length + 1);
			eventHandlers[eventHandlers.length-1] = eventHandler;
		}

		@Override
		public FileType getFileType() {
			return FileType.CSV;
		}
		@Override
		public String getFilename() {
			return destination;
		}
		@Override
		public String getSource() {
			return source;
		}
		@Override
		public int getQueueLength() {
			return queueSize;
		}
		@Override
		public boolean generateReport() {
			return generateReport;
		}
		@Override
		public EventHandler<RegistrationEvent>[] getEventHandlers() {
			return eventHandlers;
		}
		@Override
		public int getBatchSize() {
			return batchSize;
		}
		public String getDestination() {
			return destination;
		}
		public void setDestination(String destination) {
			this.destination = destination;
		}
		public boolean isGenerateReport() {
			return generateReport;
		}
		public void setGenerateReport(boolean generateReport) {
			this.generateReport = generateReport;
		}
		public int getQueueSize() {
			return queueSize;
		}
		public void setQueueSize(int queueSize) {
			this.queueSize = queueSize;
		}
		public void setSource(String source) {
			this.source = source;
		}
		public void setBatchSize(int batchSize) {
			this.batchSize = batchSize;
		}
		public void setEventHandlers(EventHandler<RegistrationEvent>[] eventHandlers) {
			this.eventHandlers = eventHandlers;
		}
		
	}
}

package com.bigmemory.samples.wan.debulker.loader;

import java.nio.MappedByteBuffer;

import com.bigmemory.samples.wan.debulker.service.DebulkingStrategy;

public interface FileReader {

	public String[] read(MappedByteBuffer buffer) throws Exception;
	
	public DebulkingStrategy getDebulkingStrategy();

}

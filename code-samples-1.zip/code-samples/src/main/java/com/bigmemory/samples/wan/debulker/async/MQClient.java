package com.bigmemory.samples.wan.debulker.async;

public interface MQClient<T> {

	public void send(T t);
	public boolean isConnected();
}

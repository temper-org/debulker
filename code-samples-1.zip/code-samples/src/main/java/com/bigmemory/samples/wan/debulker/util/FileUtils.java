package com.bigmemory.samples.wan.debulker.util;

import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;

import com.bigmemory.samples.wan.debulker.loader.MemoryMappedFileReaderWorker;
import com.bigmemory.samples.wan.debulker.service.DebulkingStrategy;

public abstract class FileUtils {

	/**
	 * 
	 * @param fileChannel
	 * @return MappedByteBuffer
	 * @throws IOException
	 */
	public final static MappedByteBuffer[] slice(FileChannel fileChannel) throws IOException {

		MappedByteBuffer[] mappedByteBuffers = new MappedByteBuffer[1];

		final long size = fileChannel.size();
		if(size > Integer.MAX_VALUE) {

			int sliceSize = Integer.MAX_VALUE, leftover = (int)(size % Integer.MAX_VALUE);
			long from = 0;

			final int threadCount = (size % Integer.MAX_VALUE) > 0 ?
					(int)(size/Integer.MAX_VALUE) + 1 : (int)(size/Integer.MAX_VALUE);
			mappedByteBuffers = new MappedByteBuffer[threadCount];

			for(int k=0; k<threadCount; ++k) {
				if(k+1 == threadCount)
					sliceSize = leftover;

				MappedByteBuffer mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, from, sliceSize);
				for(int i=(int)sliceSize-1; i>0; i--) {

					if((char) mappedByteBuffer.get(i) == '\r') {
						int length = i+1;

						mappedByteBuffers[k] = fileChannel.map(FileChannel.MapMode.READ_ONLY, from, length);
						leftover += (sliceSize - length);
						from += length;
						break;
					}
				}
			}
		} else {
			mappedByteBuffers[0] = fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, size);
		}
		return mappedByteBuffers;
	}

	/**
	 * 
	 * @param fileChannel
	 * @param batchSize
	 * @param reportHandler
	 * @param eventHandler
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public final static Callable<String[]>[] getProcessors(BlockingQueue<String> queue,
			FileChannel fileChannel,
			DebulkingStrategy debulkingStrategy) {
		Callable<String[]>[] processors = null;
		try {
			MappedByteBuffer[] slices = FileUtils.slice(fileChannel);
			processors = new MemoryMappedFileReaderWorker[slices.length];
			for(int i=0; i<slices.length; ++i)
				processors[i] = new MemoryMappedFileReaderWorker(slices[i], debulkingStrategy, queue);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return processors;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected final static String[] readFirst(BlockingQueue<String> queue,
			FileChannel fileChannel,
			DebulkingStrategy debulkingStrategy) throws Exception {
		Callable<String[]>[] processors = null;
		try {
			MappedByteBuffer[] slices = FileUtils.slice(fileChannel);
			processors = new MemoryMappedFileReaderWorker[slices.length];
			for(int i=0; i<slices.length; ++i)
				processors[i] = new MemoryMappedFileReaderWorker(slices[i], debulkingStrategy, queue);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return processors[0].call();
	}


}
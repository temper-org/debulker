﻿using System;
using System.Collections.Generic;
using System.IO;
using Terracotta.Ehcache.Serialization;
using Terracotta.Ehcache.Thrift;
using Terracotta.Ehcache.Utilities;

namespace RecipeProject
{
    public class RecipeSerializer : ICacheSerializer<String, RecipeProject.RecipeStructure>
    {
        public static readonly string KEY_NAME = "RecipeName";

        public Value SerializeKey(string key)
        {
            Value val = new Value();
            val.StringValue = key;
            return val;
        }

        public string DeserializeKey(Value serializedKey)
        {
            return serializedKey.StringValue;
        }

        public StoredValue SerializeValue(RecipeProject.RecipeStructure objectValue)
        {
            Dictionary<String, Object> nvPairs = new Dictionary<String, Object>();
            nvPairs.Add(KEY_NAME, objectValue.name);
            MemoryStream ms = new MemoryStream();
            ProtoBuf.Serializer.Serialize<RecipeProject.RecipeStructure>(ms,objectValue);
            return ValueHelper.NullSafeStoredValue(ms.ToArray(), nvPairs);
        }

        public RecipeProject.RecipeStructure DeserializeValue(StoredValue value)
        {
            MemoryStream ms = new MemoryStream(value.Value.BinaryValue);
            return ProtoBuf.Serializer.Deserialize<RecipeProject.RecipeStructure>(ms);
        }

    }
}

package com.bigmemory.samples.wan.debulker.transformer;

/**
 * 
 * @author dennis.temper
 *
 */
public class TransformerFactory {

	public final static Transformer<?, ?> getTransformer(TransformerType type) {
		switch(type) {
        	case CSV:
        		return new CSVTransformer();
		case JSON:
			break;
		case XML:
			break;
		default:
			throw new UnsupportedOperationException("Undetected transformer type encountered" + type);
		}
		throw new UnsupportedOperationException("Undetected transformer type encountered" + type);
	}
	
	public enum TransformerType {
		CSV, JSON, XML
	}
}

package com.bigmemory.samples.wan.events.registration;

import com.bigmemory.samples.wan.events.Event;

public class RegistrationEvent implements Event<RegistrationVO> {
	
	private final Long eventID;
	private final RegistrationVO eventBody;

	public RegistrationEvent(RegistrationVO eventBody) {
		super();
		
		this.eventID = eventBody.getId();
		this.eventBody = eventBody;
	}

	public Long getEventID() {

		return this.eventID;
	}

	public RegistrationVO getEventBody() {

		return this.eventBody;
	}

}

package com.bigmemory.samples.wan.debulker.service;

import com.bigmemory.samples.wan.events.EventHandler;
import com.bigmemory.samples.wan.events.registration.RegistrationEvent;

public interface DebulkingStrategy {

	public FileType getFileType();
	public String getFilename();
	public String getSource();
	
	public int getBatchSize();
	public int getQueueLength();
	public boolean generateReport();
	
	public EventHandler<RegistrationEvent>[] getEventHandlers();
	public void addEventHandler(EventHandler<RegistrationEvent> eventHandler);
}

package com.bigmemory.samples.wan.debulker.reporting;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.time.Duration;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;

import com.bigmemory.samples.wan.events.EventHandler;
import com.bigmemory.samples.wan.events.registration.RegistrationEvent;

public class MemoryMappedFileWriter implements EventHandler<RegistrationEvent>, FileWriter {

	@Autowired
	private String filename;
	private int reportSize = 0;
	private int idx = 0;

	private ByteBuffer[] lines;// = new ByteBuffer[100000000];
	
	public MemoryMappedFileWriter() {
	}
	
	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	private final static String csvReportLine(int j, String[] split) {
		
		StringBuilder sb = new StringBuilder();
		sb.append(j);
		for(int i=1; i<split.length; ++i) {
			sb.append(',');
			sb.append(split[i]);
		}
		sb.append('\n');
		return sb.toString();
	}

	/**
	 * 
	 * @param filename
	 * @param lines
	 */
	@Override
	public Integer write(String filename, ByteBuffer[] lines) {

		RandomAccessFile randomAccessFile = null;
		try {
			File file = new File(filename);
			file.delete();
			randomAccessFile = new RandomAccessFile(file, "rw");
			FileChannel fileChannel = randomAccessFile.getChannel();
			MappedByteBuffer mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, 0, reportSize);

			int start = 0;
			for(int i=0; i<lines.length; i++) {
				if(!mappedByteBuffer.hasRemaining()) {
					start += mappedByteBuffer.position();
					mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, start, reportSize);
				}
				mappedByteBuffer.put(lines[i]);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		//System.out.println("<-\t" + idx + "\t" + Duration.between(start, Instant.now()).toMillis() + " millis");	
		return idx;
	}

	final Instant start = Instant.now();
	
//	public Integer report() {
//
//		long elapsed; int tps;
//		
//		String element = null;
//		try {
//			while(isRunning) {
//				while((element = queue.poll()) != null) {
//					if(element == STOP) {
//						queue.add(STOP);
//						write(dumpFile, lines);
//						return idx;
//					}
//					ReportLine reportLine = new DefaultReportLine(++idx, element.split(","));
//					lines[reportLine.getIndex()] =
//							Charset.defaultCharset().encode(CharBuffer.wrap(csvReportLine(reportLine.getIndex(),
//									reportLine.getLine()).toCharArray()));
//					reportSize += lines[reportLine.getIndex()].remaining();
//
//					elapsed = Duration.between(start, Instant.now()).toMillis();
//					tps = ((int)elapsed/1000 > 0) ? ((int)idx/((int)elapsed/1000)) : 0;
//					System.out.print('\r');System.out.print(idx + "\t\t\t" + MetricsUtil.formatMillis(elapsed) + "\t\t" + tps + "\tTPS");
//				}
//			}
//		} catch(Exception e) {
//			e.printStackTrace();
//		}
//		return idx;
//	}
	
	@Override
	public Integer write(String[] reportLines) {
		lines = new ByteBuffer[reportLines.length];
		for(String line : reportLines)
			addLine(line);
		return write(filename, lines);
	}
	
	public void addLine(String line) {
		
//		long elapsed; int tps;
		ReportLine reportLine = new DefaultReportLine(++idx, line.split(","));
		lines[reportLine.getIndex()-1] = Charset.defaultCharset().encode(CharBuffer.wrap(csvReportLine(reportLine.getIndex(), reportLine.getLine()).toCharArray()));
		reportSize += lines[reportLine.getIndex()-1].remaining();

//		elapsed = Duration.between(start, Instant.now()).toMillis();
//		tps = ((int)elapsed/1000 > 0) ? ((int)idx/((int)elapsed/1000)) : 0;
//		System.out.print(tps + "\r");//System.out.print(idx + "\t\t\t" + MetricsUtil.formatMillis(elapsed) + "\t\t" + tps + "\tTPS\r");	
	}

	@Override
	public void handle(RegistrationEvent event) {
		addLine(event.getEventBody().toString());
	}

	@Override
	public Integer handleAll(RegistrationEvent[] events) {
		for(RegistrationEvent event : events)
			handle(event);
		return events.length;
	}
}
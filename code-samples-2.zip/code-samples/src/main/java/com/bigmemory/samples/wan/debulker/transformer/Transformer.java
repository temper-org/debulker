package com.bigmemory.samples.wan.debulker.transformer;

/**
 * 
 * @author dennis.temper
 *
 * @param <T>
 * @param <V>
 */
public interface Transformer<T, V> {
	
	/**
	 * Designed for: Event - ByteBuffer buffer
	 */
	public T transform(V v);
}
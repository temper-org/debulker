package com.bigmemory.samples.wan.events;

public interface ReportEventHandler<K, V> {

	public void handle(K k, V v);
}

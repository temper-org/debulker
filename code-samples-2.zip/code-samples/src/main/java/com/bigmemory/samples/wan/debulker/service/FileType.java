package com.bigmemory.samples.wan.debulker.service;

public enum FileType {

	CSV, JSON, XML
}

package com.bigmemory.samples.wan.debulker.synch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bigmemory.samples.wan.debulker.DebulkingService;
import com.bigmemory.samples.wan.events.EventHandler;
import com.bigmemory.samples.wan.events.registration.RegistrationEvent;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.Configuration;
import net.sf.ehcache.config.TerracottaClientConfiguration;
import net.sf.ehcache.config.TerracottaConfiguration;

public class EhcacheClient implements EventHandler<RegistrationEvent> {

	@Autowired
	private String cacheName;
	@Autowired
	private String url;
	
	private static EventHandler<RegistrationEvent> replication;
	private static DebulkingService service;

	private CacheManager cacheManager;
	private Ehcache cache;
	
	public EhcacheClient() {
		
	}
	
	public void init() {
		
		final CacheConfiguration cacheConfig = new CacheConfiguration()
				.name(cacheName)
				.maxEntriesLocalHeap(10000000)
				.terracotta(new TerracottaConfiguration().clustered(true));

		final Configuration cacheManagerConfig = new Configuration()
				.name(CacheManager.DEFAULT_NAME)
				.terracotta(new TerracottaClientConfiguration().url(url).rejoin(true).wanEnabledTSA(true))
				.cache(cacheConfig);

		cacheManager = CacheManager.create(cacheManagerConfig);
		cache = cacheManager.getEhcache(cacheName);

		System.out.println("Successfully connected to '" + cache.getName() + "'");
	}

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		try {
			service = (DebulkingService) context.getBean("serviceClass");
			replication = (EventHandler<RegistrationEvent>) context.getBean("wanReplication");
			service.updateDebulkingStrategy(replication);
		} finally {
			((ClassPathXmlApplicationContext)context).close();
		}
	}

	public void handle(RegistrationEvent t) {

		cache.put(new Element("k" + t.getEventID(), t.getEventBody()));
	}

	public Integer handleAll(RegistrationEvent[] events) {

		final Element[] elements = new Element[events.length];
		for(int i=0; i<events.length; ++i)
			elements[i] = new Element("k" + i, events[i].getEventBody());
		
		EXECUTOR.execute(new Runnable() {
		    @Override 
		    public void run() {
		    	cache.putAll(new ArrayList<Element>(Arrays.asList(elements)));
		    }
		});

		return events.length;
	}

	private final static Executor EXECUTOR = Executors.newSingleThreadExecutor();

	public String getCacheName() {
		return cacheName;
	}

	public void setCacheName(String cacheName) {
		this.cacheName = cacheName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}

package com.bigmemory.samples.wan.debulker.loader;

import java.nio.MappedByteBuffer;
import java.util.Arrays;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;

import com.bigmemory.samples.wan.debulker.service.DebulkingStrategy;
import com.bigmemory.samples.wan.debulker.transformer.CSVTransformer;
import com.bigmemory.samples.wan.events.EventHandler;
import com.bigmemory.samples.wan.events.registration.RegistrationEvent;

public class MemoryMappedFileReader<T> implements FileReader {

	private int batchSize = 0;
	
	@Autowired
	private DebulkingStrategy debulkingStrategy;
	
	public void setDebulkingStrategy(DebulkingStrategy debulkingStrategy) {
		this.debulkingStrategy = debulkingStrategy;
	}
	public DebulkingStrategy getDebulkingStrategy() {
		return this.debulkingStrategy;
	}
	
	public MemoryMappedFileReader() {
		;
	}
	
	public void init() {
		
		this.batchSize = debulkingStrategy.getBatchSize();
	}
	
	
	@Override
	public String[] read(MappedByteBuffer buffer) throws Exception {
		
		RegistrationEvent[] events = null;
		String[] response = new String[0];//20,000,000	100,000,000
		String[] lines = new String[1];
		
		if(batchSize>0) {
			if(debulkingStrategy.getEventHandlers() != null && debulkingStrategy.getEventHandlers().length>0) {
				events = new RegistrationEvent[batchSize];
			}
			lines = new String[batchSize];
		}
//		System.out.println("Chunk size \t" + buffer.limit() + " bytes");
		
		int idx = 0;										//Metrics
//		Instant start = Instant.now();						//Metrics
		for(int i=0; i<buffer.limit(); i++) {
			
			StringBuilder line = new StringBuilder();
			char character;
			while((character = (char) buffer.get())!= '\n') {
				i++;
				line.append(character);
			}
			lines[idx] = line.toString();
			
			/** Batching prior to caching */
			if(batchSize>0) {
				/** Batch events */
				if(events != null)
					events[idx] = new RegistrationEvent(CSVTransformer.transformCSVLine(line.toString()));
				if(((idx+1) % batchSize) == 0) { //TODO:
					for(EventHandler<RegistrationEvent> eventHandler : debulkingStrategy.getEventHandlers())
						  eventHandler.handleAll(events);

					if(events != null)
						events = new RegistrationEvent[batchSize];
					response = Stream.concat(Arrays.stream(response), Arrays.stream(lines)).toArray(String[]::new);//Stream.of
					
					lines = new String[batchSize];
					idx = 0;
				} else {
					++idx;
				}
			} else {
				response = Stream.concat(Arrays.stream(response), Arrays.stream(new String[]{line.toString()})).toArray(String[]::new);//response[j] = line.toString();
				//TODO: prohibit the use of single-shot operations
				for(EventHandler<RegistrationEvent> eventHandler : debulkingStrategy.getEventHandlers()) {
					eventHandler.handle(new RegistrationEvent(CSVTransformer.transformCSVLine(line.toString())));
				}
			}
			line.setLength(0);
		}
	   // System.out.println("->\t" + response.length + "\t" + Duration.between(start, Instant.now()).toMillis() + " millis");
	    return response;
	}
	
}
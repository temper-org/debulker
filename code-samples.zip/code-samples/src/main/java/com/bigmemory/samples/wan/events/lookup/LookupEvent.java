package com.bigmemory.samples.wan.events.lookup;

import com.bigmemory.samples.wan.events.EventHandler;

public class LookupEvent implements EventHandler<LookupVO> {

	public void handle(LookupVO lookup) {
		;
	}
	public void handleAll(LookupVO[] lookups) {
		;
	}

}

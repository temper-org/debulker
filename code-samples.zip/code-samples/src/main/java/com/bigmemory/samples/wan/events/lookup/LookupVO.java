package com.bigmemory.samples.wan.events.lookup;

import java.io.Serializable;

public class LookupVO implements Serializable {

	private static final long serialVersionUID = -1743690579951097192L;

}

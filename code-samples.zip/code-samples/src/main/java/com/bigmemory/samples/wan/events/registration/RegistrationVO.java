package com.bigmemory.samples.wan.events.registration;

import java.io.Serializable;

import org.jsefa.csv.annotation.CsvField;

//@CsvDataType()
public class RegistrationVO implements Serializable {

	private static final long serialVersionUID = 1076682700675680685L;

	private Long id;@CsvField(pos = 2)//, format = "dd.MM.yyyy")
	private String actionType;
	private String proxyType;
	private Long proxyValue;
	private String accountType;
	private Boolean suspended;
	private String accountValue;
	private String accountName;
	private String participant;
	private Boolean active;
	private String firstName;
	private String secondName;
	private String lastName;

	public RegistrationVO() {
		;
	}
	
	/**
	 * 
	 * @param id
	 * @param actionType
	 * @param proxyType
	 * @param proxyValue
	 * @param accountType
	 * @param suspended
	 * @param accountValue
	 * @param accountName
	 * @param participant
	 * @param active
	 * @param firstName
	 * @param secondName
	 * @param lastName
	 */
	public RegistrationVO(Long id, String actionType, String proxyType, Long proxyValue, String accountType,
								Boolean suspended, String accountValue, String accountName, String participant,
								Boolean active, String firstName, String secondName, String lastName) {
		super();
		
		this.id = id;
		this.actionType = actionType;
		this.proxyType = proxyType;
		this.proxyValue = proxyValue;
		this.accountType = accountType;
		this.suspended = suspended;
		this.accountValue = accountValue;
		this.accountName = accountName;
		this.participant = participant;
		this.active = active;
		this.firstName = firstName;
		this.secondName = secondName;
		this.lastName = lastName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getProxyType() {
		return proxyType;
	}

	public void setProxyType(String proxyType) {
		this.proxyType = proxyType;
	}

	public Long getProxyValue() {
		return proxyValue;
	}

	public void setProxyValue(Long proxyValue) {
		this.proxyValue = proxyValue;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountValue() {
		return accountValue;
	}

	public void setAccountValue(String accountValue) {
		this.accountValue = accountValue;
	}

	@Override
	public String toString() {
		return String.format(//"Registration [id=%s, actionType=%s, proxyType=%s, proxyValue=%s, accountType=%s, suspended=%s, accountValue=%s, accountName=%s, participant=%s, active=%s, firstName=%s, secondName=%s, lastName=%s]",
				"Registration [%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s]",
				id, actionType, proxyType, proxyValue, accountType, suspended, accountValue, accountName,
				participant, active, firstName, secondName, lastName);
	}

	public String toCSVString() {
		return String.format("%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s",
								id, actionType, proxyType, proxyValue, accountType,
								suspended, accountValue, accountName, participant,
								active, firstName, secondName, lastName);
	}
	
}

package com.bigmemory.samples.wan.debulker;

import com.bigmemory.samples.wan.events.EventHandler;
import com.bigmemory.samples.wan.events.registration.RegistrationEvent;

public interface DebulkingService {

	public void debulk();
	public void updateDebulkingStrategy(EventHandler<RegistrationEvent> eventHandler);
}

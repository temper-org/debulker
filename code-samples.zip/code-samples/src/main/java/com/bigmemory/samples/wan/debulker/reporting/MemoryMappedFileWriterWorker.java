package com.bigmemory.samples.wan.debulker.reporting;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;

import com.bigmemory.samples.wan.debulker.util.MetricsUtil;
import com.bigmemory.samples.wan.events.EventHandler;
import com.bigmemory.samples.wan.events.registration.RegistrationEvent;

public class MemoryMappedFileWriterWorker implements Callable<Integer>, EventHandler<RegistrationEvent> {

	private String dumpFile;
	private int reportSize = 0;
	private int idx = 0;

	private ByteBuffer[] lines;// = new ByteBuffer[100000000];
	final protected BlockingQueue<String> queue;// = new ConcurrentLinkedQueue<MemoryMappedFileWriter.ReportLine>();//10, 000, 0000 records at max allowed
	
	public MemoryMappedFileWriterWorker(BlockingQueue<String> queue, String filename) {
		
		this.queue = queue;
		this.dumpFile = filename;
	}
	
	private final String csvReportLine(int j, String[] split) {
		
		StringBuilder sb = new StringBuilder();
		sb.append(j);
		for(int i=1; i<split.length; ++i) {
			sb.append(',');
			sb.append(split[i]);
		}
		sb.append('\r');
		return sb.toString();
	}

	/**
	 * 
	 * @param filename
	 * @param lines
	 */
	private final int write(String filename, ByteBuffer[] lines) {

		RandomAccessFile randomAccessFile = null;
		try {
			File file = new File(filename);
			file.delete();
			randomAccessFile = new RandomAccessFile(file, "rw");
			FileChannel fileChannel = randomAccessFile.getChannel();
			MappedByteBuffer mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, 0, reportSize);

			int start = 0;
			for(int i=0; i<lines.length; i++) {        
				if(!mappedByteBuffer.hasRemaining()) {
					start += mappedByteBuffer.position();
					mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, start, reportSize);
				}
				mappedByteBuffer.put(lines[i]);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		System.out.println("Reported\t\t" + idx + " registrations, in " + Duration.between(start, Instant.now()).toMillis() + " milliseconds");
		
		return idx;
	}

	final Instant start = Instant.now();
	
	@Override
	public Integer call() {

		long elapsed; int tps;
		
		String element = null;
		try {
			while(isRunning) {
				while((element = queue.poll()) != null) {
					if(element == STOP) {
						queue.add(STOP);
						write(dumpFile, lines);
						return idx;
					}
					ReportLine reportLine = new DefaultReportLine(++idx, element.split(","));
					lines[reportLine.getIndex()] =
							Charset.defaultCharset().encode(CharBuffer.wrap(csvReportLine(reportLine.getIndex(),
									reportLine.getLine()).toCharArray()));
					reportSize += lines[reportLine.getIndex()].remaining();

					elapsed = Duration.between(start, Instant.now()).toMillis();
					tps = ((int)elapsed/1000 > 0) ? ((int)idx/((int)elapsed/1000)) : 0;
					System.out.print('\r');System.out.print(idx + "\t\t\t" + MetricsUtil.formatMillis(elapsed) + "\t\t" + tps + "\tTPS");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return idx;
	}

	private boolean isRunning = true;
	public boolean isRunning() {
		
		return this.isRunning;
	}
	
	private final String STOP = new String("STOP!");
	public void finish() {

		isRunning = false;
		queue.add(STOP);
	}
	
	public Integer writeReportLines(String[] reportLines) {
		lines = new ByteBuffer[reportLines.length];
		for(String line : reportLines)
			addLine(line);
		return write(dumpFile, lines);
	}
	
	public void addLine(String line) {
		
//		long elapsed; int tps;
		ReportLine reportLine = new DefaultReportLine(++idx, line.split(","));
		lines[reportLine.getIndex()-1] = Charset.defaultCharset().encode(CharBuffer.wrap(csvReportLine(reportLine.getIndex(), reportLine.getLine()).toCharArray()));
		reportSize += lines[reportLine.getIndex()-1].remaining();

//		elapsed = Duration.between(start, Instant.now()).toMillis();
//		tps = ((int)elapsed/1000 > 0) ? ((int)idx/((int)elapsed/1000)) : 0;
//		System.out.print(tps + "\r");//System.out.print(idx + "\t\t\t" + MetricsUtil.formatMillis(elapsed) + "\t\t" + tps + "\tTPS\r");	
	}

	@Override
	public void handle(RegistrationEvent event) {
		addLine(event.getEventBody().toString());
	}

	@Override
	public void handleAll(RegistrationEvent[] events) {
		for(RegistrationEvent event : events)
			handle(event);
	}
}
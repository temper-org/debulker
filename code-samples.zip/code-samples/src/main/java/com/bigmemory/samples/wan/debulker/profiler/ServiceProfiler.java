package com.bigmemory.samples.wan.debulker.profiler;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class ServiceProfiler {

	//Double period for recursively scanning the packages
	@Pointcut("execution(* com.bigmemory.samples.wan..*.*(..))")
	public void businessMethods() {
		;
	}

	@Around("businessMethods()")
	public Object profile(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {

		Runtime runtime = Runtime.getRuntime();
	    runtime.gc();														//GC
	    long memoryBefore = runtime.totalMemory() - runtime.freeMemory();	//RAM utilisation
	    
		long start = System.currentTimeMillis();							//Latency
		Object output = proceedingJoinPoint.proceed();
		long memoryAfter = runtime.totalMemory() - runtime.freeMemory();
		
		System.out.println("\t" + (System.currentTimeMillis() - start) + "\tms" + "\t" + bytesToMegabytes(memoryAfter - memoryBefore) + " \tMB\t" + proceedingJoinPoint.toShortString());
		return output;
	}

	private static final long MEGABYTE = 1024L*1024L;

	public static long bytesToMegabytes(long bytes) {
		return bytes/MEGABYTE;
	}
}
package com.bigmemory.samples.wan.debulker.reporting;

import java.nio.ByteBuffer;

public interface FileWriter {

	public void addLine(String line);
	public Integer write(String filename, ByteBuffer[] lines);
	public Integer writeLines(String[] lines);
}

package com.bigmemory.samples.wan.debulker.reporting;

public 	interface ReportLine {

	public Integer getIndex();
	public String[] getLine();
}
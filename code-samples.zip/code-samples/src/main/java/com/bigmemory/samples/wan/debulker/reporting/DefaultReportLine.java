package com.bigmemory.samples.wan.debulker.reporting;

public class DefaultReportLine implements ReportLine {

	private Integer index;
	private String[] line;

	public DefaultReportLine(Integer index, String[] line) {

		this.index = index;
		this.line = line;
	}
	public Integer getIndex() {

		return this.index;
	}

	public String[] getLine() {

		return this.line;
	}
}
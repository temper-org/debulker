package com.bigmemory.samples.wan.events;

public interface EventHandler<T> {

	public void handle(T t);
	public void handleAll(T[] t);
}

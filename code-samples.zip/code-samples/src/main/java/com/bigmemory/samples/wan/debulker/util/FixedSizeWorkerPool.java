package com.bigmemory.samples.wan.debulker.util;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.bigmemory.samples.wan.debulker.loader.MemoryMappedFileReaderWorker;

public class FixedSizeWorkerPool {

	private ThreadPoolExecutor executorPool;
	private ServerMonitorWorkerThread monitor;
	private Thread monitorThread;

	private final static int MONITOR_THREAD_SLEEP = 10;

	public FixedSizeWorkerPool(int minThreadCount, int maxThreadCount, final String serverName) {

		GenericRejectedExecutionHandler rejectionHandler = new GenericRejectedExecutionHandler();
		ThreadFactory threadFactory = Executors.defaultThreadFactory();

		this.executorPool = new ThreadPoolExecutor(minThreadCount, maxThreadCount, 10, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(maxThreadCount), threadFactory, rejectionHandler);

		this.monitor = new ServerMonitorWorkerThread(executorPool, MONITOR_THREAD_SLEEP, serverName);
		this.monitorThread = new Thread(monitor);
		monitorThread.start();
	}

	public void submit(Runnable runnable) {

		this.executorPool.execute(runnable);
	}


	class GenericRejectedExecutionHandler implements RejectedExecutionHandler {

		@SuppressWarnings("rawtypes")
		@Override
		public void rejectedExecution(Runnable runnable, ThreadPoolExecutor executor) {

			if(runnable instanceof MemoryMappedFileReaderWorker)
				((MemoryMappedFileReaderWorker)runnable).terminate();
			System.out.println(runnable.toString() + " rejected.");
		}

	}
	class ServerMonitorWorkerThread implements Runnable {

		private final String serverName;

		private ThreadPoolExecutor executor;

		private int seconds;
		private boolean run = true;

		public ServerMonitorWorkerThread(ThreadPoolExecutor executor, int delay, String serverName) {

			this.executor = executor;
			this.seconds = delay;
			this.serverName = serverName;
		}

		public void shutdown() {
			this.run = false;
		}

		@Override
		public void run() {

			while(run) {
				System.out.println(
						String.format("["+serverName+"] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s",
								this.executor.getPoolSize(),
								this.executor.getCorePoolSize(),
								this.executor.getActiveCount(),
								this.executor.getCompletedTaskCount(),
								this.executor.getTaskCount(),
								this.executor.isShutdown(),
								this.executor.isTerminated()));
				try {
					Thread.sleep(seconds*1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
	}
}
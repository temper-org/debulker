//
// Created by Alex Snaps on 10/29/13.
// Copyright (c) 2013 Terracotta. All rights reserved.
//


#include "RecipeProtoBufSerializer.h"

ValueObject RecipeProtoBufSerializer::serializeKey(std::string &deserializedKey) {
    return ValueObject::stringValue(deserializedKey);
}

std::string RecipeProtoBufSerializer::deserializeKey(ValueObject &serializedKey) {
    return serializedKey.getString();
}

CacheValue RecipeProtoBufSerializer::serializeValue(RecipeStructure &deserializedValue) {
    CacheValue value = CacheValue();
    value.setValue(ValueObject::binaryValue(deserializedValue.SerializeAsString()));
    std::map<std::string, ValueObject> nvPairs;
    nvPairs[KEY_NAME] = ValueObject::stringValue(deserializedValue.name());
    value.setNvPairs(nvPairs);
    return value;
}

RecipeStructure RecipeProtoBufSerializer::deserializeValue(CacheValue &serializedValue) {
    RecipeStructure recipe = RecipeProject::RecipeStructure();
    if (serializedValue.isValueSet()) {
        recipe.ParseFromString(serializedValue.getValue().getBinary());
    }
    return recipe;
}
